# Configuración de la base de datos
SQLALCHEMY_DATABASE_URI = 'sqlite:///../instance/database.db'
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Otras configuraciones
DEBUG = True
SECRET_KEY = 'Lieberm0rder' 
UPLOAD_FOLDER = '/static/images'
